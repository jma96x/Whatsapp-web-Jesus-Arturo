package persistencia;

@SuppressWarnings("serial")
public class DAOException extends Exception {

	public DAOException(String mensaje) {
		super(mensaje);
	}
}
