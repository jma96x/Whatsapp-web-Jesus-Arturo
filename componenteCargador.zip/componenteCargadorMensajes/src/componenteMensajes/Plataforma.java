package componenteMensajes;


public enum Plataforma {
	IOS, ANDROID
}
