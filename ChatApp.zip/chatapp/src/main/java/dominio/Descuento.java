package dominio;

public interface Descuento {
	public double calcDescuento();
}
